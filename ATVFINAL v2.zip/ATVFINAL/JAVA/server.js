// server.js
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');  // Importa o CORS

const app = express();
const port = 3000;

// Habilitar CORS para permitir que o frontend acesse o backend
app.use(cors()); 

// Configuração da conexão com o banco de dados
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',  // Altere conforme seu usuário MySQL
  password: '',  // Altere conforme sua senha MySQL
  database: 'pedidos'
});

// Testando a conexão com o banco de dados
db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados!');
});

// Middleware para servir arquivos estáticos (CSS, JS, HTML)
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});

// Tratativas da pagina produtos.html em diante

// Rota para listar todos os produtos
app.get('/api/produtos', (req, res) => {
  db.query('SELECT * FROM produtos', (err, results) => {
    if (err) {
      console.error('Erro ao buscar produtos:', err);
      res.status(500).send('Erro ao buscar produtos');
      return;
    }
    res.json(results);  
  });
});

// Rota para obter os detalhes de um produto específico
app.get('/api/produtos/:id_prod', (req, res) => {
  const { id_prod } = req.params;
  db.query('SELECT * FROM produtos WHERE id_prod = ?', [id_prod], (err, results) => {
    if (err) {
      console.error('Erro ao buscar produto:', err);
      res.status(500).send('Erro ao buscar produto');
      return;
    }
    if (results.length > 0) {
      res.json(results[0]);  // Retorna o produto único
    } else {
      res.status(404).send('Produto não encontrado');
    }
  });
});

// Rota para excluir um produto
app.delete('/api/produto/:id', (req, res) => {
  const id = req.params.id;
  db.query('DELETE FROM produtos WHERE id_prod = ?', [id], (err) => {
      if (err) {
          console.error('Erro ao excluir produto:', err);
          res.status(500).send('Erro ao excluir produto');
          return;
      }
      res.json({ message: 'Produto Excluído com sucesso' });
  });
});
// Rota para alterar um produto
app.put('/api/produto/:id', async (req, res) => {
  const { id } = req.params;
  const { desc_prod, valor_prod } = req.body;

  console.log('Dados recebidos no servidor:', req.body);

  db.query(
    'UPDATE produtos SET desc_prod = ?, valor_prod = ? WHERE id_prod = ?',
    [desc_prod, valor_prod, id],
    (err, result) => {
      if (err) {
        console.error('Erro ao atualizar o produto:', err);
        res.status(500).send('Erro ao atualizar o produto');
        return;
      }
      if (result.affectedRows === 0) {
        res.status(404).send('Produto não encontrado');
      } else {
        res.json({ message: 'Produto atualizado com sucesso' });
      }
    }
  );
});
// Rota para Inserir um Produto
app.post('/api/produtos', (req, res) => {
  const { desc_prod, valor_prod } = req.body;
  db.query(
    'INSERT INTO produtos (desc_prod, valor_prod) VALUES (?, ?)',
    [desc_prod, valor_prod],
    (err, result) => {
      if (err) {
        console.error('Erro ao adicionar ao carrinho:', err);
        res.status(500).send('Erro ao adicionar ao carrinho');
        return;
      }
      res.json({ message: 'Produto adicionado ao carrinho' });
    }
  );
});

// Tratativas da pagina carrinho.html em diante

// Rota para adicionar um produto ao carrinho
app.post('/api/adicionarCarrinho', (req, res) => {
  const { id_prod, desc_prod, valor_prod, qtd_prod } = req.body;
  db.query(
    'INSERT INTO carrinho (id_prod, desc_prod, valor_prod, qtd_prod) VALUES (?, ?, ?, ?)',
    [id_prod, desc_prod, valor_prod, qtd_prod],
    (err, result) => {
      if (err) {
        console.error('Erro ao adicionar ao carrinho:', err);
        res.status(500).send('Erro ao adicionar ao carrinho');
        return;
      }
      res.json({ message: 'Produto adicionado ao carrinho' });
    }
  );
});

// Rota para listar os itens no carrinho
app.get('/api/carrinho', (req, res) => {
  db.query('SELECT * FROM carrinho', (err, results) => {
    if (err) {
      console.error('Erro ao buscar carrinho:', err);
      res.status(500).send('Erro ao buscar carrinho');
      return;
    }
    res.json(results);
  });
});

// Rota para excluir item do carrinho
app.delete('/api/carrinho/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM carrinho WHERE id = ?', [id], (err, result) => {
      if (err) {
        console.error('Erro ao excluir item do carrinho:', err);
        res.status(500).send('Erro ao excluir item');
        return;
      }
      if (result.affectedRows === 0) {
        res.status(404).send('Item não encontrado');
      } else {
        res.json({ message: 'Item excluído do carrinho' });
      }
    });
  });
  
  // Rota para atualizar a quantidade de um item no carrinho
  app.put('/api/carrinho/:id', (req, res) => {
    const { id } = req.params;
    const { qtd_prod } = req.body;  // Nova quantidade
  
    // Verifica se a quantidade foi fornecida e é válida
    if (qtd_prod <= 0) {
      return res.status(400).send('Quantidade inválida');
    }
  
    db.query(
      'UPDATE carrinho SET qtd_prod = ? WHERE id = ?',
      [qtd_prod, id],
      (err, result) => {
        if (err) {
          console.error('Erro ao atualizar quantidade do carrinho:', err);
          res.status(500).send('Erro ao atualizar quantidade');
          return;
        }
        if (result.affectedRows === 0) {
          res.status(404).send('Item não encontrado');
        } else {
          res.json({ message: 'Quantidade atualizada' });
        }
      }
    );
  });

  // Rota para obter a quantidade de itens no carrinho em vermelho
  app.get('/api/carrinho/quantidade', (req, res) => {
    //db.query('SELECT COUNT(*) AS total FROM carrinho', (err, results) => {
      db.query('SELECT SUM(qtd_prod) AS total FROM carrinho', (err, results) => {
      if (err) {
        console.error('Erro ao buscar carrinho:', err);
        res.status(500).send('Erro ao buscar carrinho');
        return;
      }
        
      res.json({ totais: results[0].total });
      });
    });

    //*****************Tratativas da pagina contato.html em diante***********************************

// Rota para adicionar um contato
app.post('/enviar/contato', (req, res) => {
  const { nome, sobrenome, empresa, email, telefone, assunto } = req.body;
  db.query(
    'INSERT INTO contatos (nome, sobrenome, empresa, email, telefone, assunto) VALUES (?, ?, ?, ?, ?, ?)',
    [nome, sobrenome, empresa, email, telefone, assunto],
    (err, result) => {
      if (err) {
        console.error('Erro ao adicionar aos Contatos:', err);
        res.status(500).send('Erro ao adicionar aos Contatos');
        return;
      }
      res.json({ message: 'Dados adicionados aos Contatos' });
    }
  );
});
  
  
  



  